<?php 
/* 	Socialia Theme's Archive Page
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since Socialia 2.0
*/

get_header(); ?>

<div id="content">
	<?php if (have_posts()) : ?>
		<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
		<?php /* If this is a category archive */ if (is_category()) { ?>
		<h1 class="arc-post-title"><?php single_cat_title(); ?></h1><h3 class="arc-src"><?php esc_html_e('now browsing by category','d5-socialia'); ?></h3>
		<?php if(trim(category_description()) != "<br />" && trim(category_description()) != '') { ?>
		<div id="description"><?php echo category_description(); ?></div>
		<?php }?>
		<div class="clear">&nbsp;</div>
		<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h1 class="arc-post-title"><?php single_tag_title(); ?></h1><h3 class="arc-src"><?php esc_html_e('now browsing by tag','d5-socialia'); ?></h3>
		<div class="clear">&nbsp;</div>
		<div class="tagcloud"><?php wp_tag_cloud(''); ?></div>
		<div class="clear">&nbsp;</div>
		<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h1 class="arc-post-title"><?php echo get_the_date('l, F jS, Y'); ?></h1><h3 class="arc-src"><?php esc_html_e('now browsing by day','d5-socialia'); ?></h3>
		<div class="clear">&nbsp;</div>
		<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h1 class="arc-post-title"><?php echo get_the_date('F, Y'); ?></h1><h3 class="arc-src"><?php esc_html_e('now browsing by month','d5-socialia'); ?></h3>
		<div class="clear">&nbsp;</div>
		<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h1 class="arc-post-title"><?php echo get_the_date('Y'); ?></h1><h3 class="arc-src"><?php esc_html_e('now browsing by year','d5-socialia'); ?></h3>
		<div class="clear">&nbsp;</div>
		<?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<h1 class="arc-post-title">Archives</h1><h3 class="arc-src"><?php esc_html_e('now browsing by author','d5-socialia'); ?></h3>
		<div class="clear">&nbsp;</div>
		<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h1 class="arc-post-title">Archives</h1><h3 class="arc-src"><?php esc_html_e('now browsing the general archives','d5-socialia'); ?></h3>
 	 	<?php } ?>

		<?php while (have_posts()) : the_post(); ?>
		
			<div <?php post_class(); ?>>
				<?php esc_html_e('Posted by','d5-socialia'); ?>: <b><?php the_author_posts_link() ?></b> | <?php esc_html_e('Posted on','d5-socialia'); ?>: <b><?php the_time('F j, Y'); ?></b>
                <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h2>
				<div class="content-ver-sep"> </div>	
				<div class="entrytext"><?php the_post_thumbnail('thumbnail'); ?>
  <?php d5socialia_content(); ?>
				</div>
				<div class="clear"> </div>
                <div class="up-bottom-border">
				<p class="postmetadata"><?php esc_html_e('Posted in','d5-socialia'); ?> <?php the_category(', ') ?> | <?php edit_post_link(esc_html__('Edit','d5-socialia'), '', ' | '); ?>  <?php comments_popup_link(esc_html__('No Comments','d5-socialia') . ' &#187;', esc_html__('One Comment','d5-socialia') . ' &#187;', '% ' . esc_html__('Comments','d5-socialia') . ' &#187;'); ?> <?php the_tags('<br />' .  esc_html__('Tags','d5-socialia') . ': ', ', ', '<br />'); ?></p>
				</div>
            
		                
                </div><!--close post class-->
	
		<?php endwhile; ?>
			
	<div id="page-nav">
	<div class="alignleft"><?php previous_posts_link('&laquo;  ' . esc_html__('Previous Entries','d5-socialia') ) ?></div>
	<div class="alignright"><?php next_posts_link(esc_html__('Next Entries','d5-socialia') .' &raquo;') ?></div>
	</div>

	<?php else : ?>

		<h1 class="arc-post-title"><?php  esc_html_e('Sorry, we could not find anything that matched your search.','d5-socialia'); ?></h1>
		
		<h3 class="arc-src"><span><?php esc_html_e('You Can Try Another Search...','d5-socialia'); ?></span></h3>
		<?php get_search_form(); ?>
		<p><a href="<?php echo esc_url(home_url()); ?>" title="<?php esc_attr_e('Browse the Home Page', 'd5-socialia'); ?>">&laquo; <?php esc_html_e('Or Return to the Home Page', 'd5-socialia'); ?></a></p><br /><br />
		<div class="content-ver-sep"></div><br />

	<?php endif; ?>

</div><!--close content id-->

<?php get_sidebar(); ?>

<?php get_footer(); ?>

