<?php
__("tree", "cluevo");
__("chapter", "cluevo");
__("course", "cluevo");
__("module", "cluevo");
?>
