<div class="cluevo-user-widget">
  <div class="cluevo-level-container" data-lms-user-level="<?php echo esc_attr(cluevo_the_lms_user_level()); ?>">
    <div class="cluevo-level"><?php esc_html(cluevo_the_lms_user_level()); ?></div>
    <div class="cluevo-exp-bar-container">
      <div class="cluevo-exp-values-container">
        <p class="cluevo-level-text"><?php esc_html_e("Level", "cluevo"); ?></p>
        <p class="cluevo-exp-stats"><?php cluevo_the_lms_user_exp(); ?> / <?php cluevo_the_lms_user_exp_next(); ?> <span class="cluevo-level-pct"><?php cluevo_the_lms_user_exp_pct(); ?>%</span></p>
      </div>
      <div class="cluevo-exp-bar">
        <div class="cluevo-progress-container">
          <span class="cluevo-progress" style="width: <?php echo 100 - cluevo_get_the_lms_user_exp_pct(); ?>%;" data-value="<?php echo esc_attr(cluevo_get_the_lms_user_exp()); ?>" data-max="<?php echo esc_attr(cluevo_get_the_lms_user_exp_next()); ?>"></span>
        </div>
      </div>
        <?php
          $comps = cluevo_get_the_lms_users_competence_scores();
          $count = 0;
          foreach ($comps as $c) { if ($c->score > 0) $count++; }
        ?>
      <div class="cluevo-exp-sub-container">
        <div class="cluevo-competences">
          <?php echo esc_html($count) . " " . esc_html__("Competences", "cluevo"); ?>
        </div>
        <?php if (cluevo_has_lms_user_title()) { ?>
        <div class="cluevo-title">
          <?php cluevo_the_lms_user_title(); ?>
        </div>
        <?php } ?>
      </div>
    </div>
  </div>

  <?php if ($count > 0) { ?>
    <div id="cluevo-polygraph">
      <svg width="200" height="200">
        <polygraph :stats="stats"></polygraph>
      </svg>
      <div class="cluevo-polygraph-stats-container">
        <div v-for="stat in stats">
          <div class="cluevo-labels">
            <label class="cluevo-comp-name">{{ stat.label }}</label>
            <label>{{ stat.value }}%</label>
          </div>
          <div class="cluevo-progress-container">
              <span class="cluevo-progress" :style="{width: (100 - stat.value) + '%'}" :data-value="stat.value" data-max="100"></span>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>

</div>
