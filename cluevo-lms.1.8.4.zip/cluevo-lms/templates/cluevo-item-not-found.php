<div class="cluevo-notice cluevo-notice-error">
  <p class="cluevo-notice-title"><?php esc_html_e("Oooops!", "cluevo"); ?></p>
  <p><?php esc_html_e("This element does not seem to exist!", "cluevo"); ?></p>
</div>
