<?php
cluevo_display_template('scorm-module-iframe');
?>
