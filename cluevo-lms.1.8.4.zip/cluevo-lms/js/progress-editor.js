var cluevoProgressEditor = new Vue({
  name: 'cluevo-progress-editor',
  el: '#cluevo-progress-editor',
  template: '#cluevo-progress-editor-template',
  data: function() {
    return {
      attemptId: null,
      userId: null,
      moduleId: null,
      start: null,
      lastActivity: null,
      minPoints: null,
      maxPoints: null,
      points: null,
      pointsPct: null,
      completionStatus: null,
      successStatus: null,
      lessonStatus: null,
      credit: null,
      closed: true,
      error: null,
    };
  },
  methods: {
    close: function() {
      this.attemptId = null;
      this.userId = null;
      this.moduleId = null;
      this.start = null;
      this.lastActivity = null;
      this.minPoints = null;
      this.maxPoints = null;
      this.points = null;
      this.pointsPct = null;
      this.completionStatus = null;
      this.successStatus = null;
      this.lessonStatus = null;
      this.credit = null;
      this.closed = true;
      this.error = null;
    },
    load: async function(userId, moduleId, attemptId) {
      let url = cluevoProgressSettings.ajax_url;
      this.userId = parseInt(userId, 10);
      this.moduleId = parseInt(moduleId, 10);
      this.attemptId = parseInt(attemptId, 10);
      url += '?action=cluevo-get-progress-entry';
      url += '&cluevo-progress-nonce=' + cluevoProgressSettings.nonce;
      url += '&user_id=' + this.userId;
      url += '&module_id=' + this.moduleId;
      url += '&attempt_id=' + this.attemptId;

      const response = await fetch(url);
      if (response) {
        let data = null;
        try {
          data = await response.json();
          this.minPoints = data.score_min;
          this.maxPoints = data.score_max;
          this.points = data.score_raw;
          this.pointsPct = data.score_scaled;
          this.completionStatus = data.completion_status;
          this.successStatus = data.success_status;
          this.lessonStatus = data.lesson_status;
          this.credit = data.credit === 'credit' ? true : false;
          this.closed = false;
        } catch (error) {
          console.error('failed to get progress entry', error);
        }
        console.log(data);
      }
    },
    save: async function() {
      let url = cluevoProgressSettings.ajax_url + '?action=cluevo-update-progress-entry';
      const payload = {
        'cluevo-progress-nonce': cluevoProgressSettings.nonce,
        completion_status: this.completionStatus,
        success_status: this.successStatus,
        attempt_id: Number(this.attemptId),
        user_id: Number(this.userId),
        module_id: Number(this.moduleId),
        score_min: Number(this.minPoints),
        score_max: Number(this.maxPoints),
        score_raw: Number(this.points),
        score_scaled: Number(this.score_scaled),
        credit: this.credit ? 'credit' : 'no-credit',
        lesson_status: this.lesson_status
      };
      try {
        const response = await fetch(url, {
          method: 'POST',
          credentials: 'include',
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            'X-WP-Nonce': cluevoProgressSettings.nonce
          },
          body: JSON.stringify(payload)
        });
        this.closed = true;
        location.reload();
      } catch (error) {
        this.error = true;
        console.error('failed to save progress update', error);
      }
    }
  }
});

jQuery(document).ready(function() {
  jQuery('.cluevo-edit-progress').click(async function() {
    const item = jQuery(this).parents('tr:first');
    const userId = item.data('user-id');
    const moduleId = item.data('module-id');
    const attemptId = item.data('attempt-id');

    cluevoProgressEditor.load(userId, moduleId, attemptId);

  });
});
