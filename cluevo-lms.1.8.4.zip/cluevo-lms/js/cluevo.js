var scorm = pipwerks.SCORM; //Shortcut
var cluevo_scorm_window = null;
var cluevoClosingLightbox = false;
var cluevoCommitTimer = null;
// SCORM 2004
var scorm_api = {
  //ModuleComplete: false,
  ItemId: null,
  LastError: 0,
  Initialized: false,
  prime: function (itemId) {
    this.ItemId = itemId;
    console.log("API primed", itemId);
  },
  Initialize: function () {
    if (this.Initialized) {
      console.warn("CLUEVO scorm api already initialized");
      return "true";
    }
    console.info("Cluevo API, lms init");
    this.ModuleRunning = true;
    this.ParmTypes = scormParameterTypes;
    this.Initialized = true;
    this._cluevo_progress = {};
    this._terminated = false;
    this.Commit();
    if (cluevoCommitTimer) {
      clearInterval(cluevoCommitTimer);
    }
    if (!cluevoCommitTimer && cluevoWpApiSettings.commitInterval) {
      let t = parseInt(cluevoWpApiSettings.commitInterval, 10);
      if (!isNaN(t) && t >= 10) {
        t *= 1000;
        let api = this;
        cluevoCommitTimer = setInterval(function () {
          api.Commit();
        }, t);
      }
    }
    return "true";
  },
  GetLastError: function () {
    var error = this.LastError;
    this.LastError = 0;
    return error;
  },
  GetErrorString: function (code) {
    return "Error: " + code;
  },
  GetValue: function (parameter) {
    //console.log("GetValue", parameter);
    this.LastError = 0;
    if (!this.Initialized) {
      this.LastError = scormErrors.GetValueBeforeInit;
      return "";
    }
    if (parameter.indexOf("._count") !== -1) {
      var pattern = "(.*)\\._count";
      var regex = new RegExp(pattern, "g");
      var match = regex.exec(parameter);
      return this.CountParameter(match[1]);
    }
    if (this.ParmTypes.hasOwnProperty(parameter)) {
      if (this.ParmTypes[parameter].hasOwnProperty("mode")) {
        if (this.ParmTypes[parameter].mode == "wo") {
          this.LastError = scormErrors.ElementIsWriteOnly;
          return "";
        }
      }
    }

    if (this.Values[parameter] !== undefined) {
      if (this.ParmTypes.hasOwnProperty(parameter)) {
        var type = this.ParmTypes[parameter].type;
        switch (type) {
          case "string":
            return "" + this.Values[parameter];
            break;
          case "real":
            var num = Number(this.Values[parameter]);
            var digits = this.ParmTypes[parameter].digits;
            return num.toPrecision(digits[1]);
            break;
          case "integer":
            return parseInt(this.Values[parameter]);
            break;
        }
      }
      return this.Values[parameter];
    } else {
      if (this.ParmTypes.hasOwnProperty(parameter)) {
        if (this.ParmTypes[parameter].hasOwnProperty("default")) {
          return this.ParmTypes[parameter].default;
        }
      }
      if (parameter.indexOf("._count") !== -1) {
        return "0";
      }
      return "";
      //console.log("not found", parameter);
      //if (parameter == "cmi.suspend_data") {
      //return JSON.stringify({
      //timeRemaining: 999,
      //duration: 999,
      //questionSubsets: [],
      //start: new Date(),
      //score: 0,
      //currentQuestion: 0,
      //questionGroupOrder: []
      //});
      //} else {
      //return '';
      //}
    }
  },
  CountParameter: function (parm) {
    var indexes = [];
    for (var key in this.Values) {
      if (key !== parm + "._count" && key !== parm + "._children") {
        if (key.indexOf(parm) > -1) {
          var pattern = parm + "\\.(\\d*)";
          var regex = new RegExp(pattern, "g");
          var match = regex.exec(key);
          if (match.length > 0) {
            if (match[1] !== "") {
              if (indexes.indexOf(match[1]) === -1) {
                indexes.push(match[1]);
              }
            }
          }
        }
      }
    }
    return indexes.length;
  },
  Values: {},
  SetValue: function (parameter, value) {
    this.LastError = 0;
    if (!this.Initialized) {
      this.LastError = scormErrors.SetValueBeforeInit;
      return "";
    }
    this.Values[parameter] = value;
    return "true";
  },
  Commit: function (input) {
    console.trace("commit");
    if (this._committing) {
      console.warn("commit in progress");
      return;
    }
    this.LastError = 0;
    let curTime = Date.now();
    /* if (this._lastCommit && curTime - this._lastCommit < 1000) {
      console.warn('commit throttled');
    } */
    this._committing = true;
    this._lastCommit = curTime;
    if (this.ItemId) {
      var url =
        cluevoWpApiSettings.root +
        "cluevo/v1/modules/" +
        this.ItemId +
        "/parameters";
      var data = this.Values;
      if (!data.hasOwnProperty("cmi.score.scaled")) {
        if (
          data.hasOwnProperty("cmi.score.raw") &&
          data.hasOwnProperty("cmi.score.max") &&
          Number(data["cmi.score.max"]) > 0
        )
          data["cmi.score.scaled"] =
            data["cmi.score.raw"] / data["cmi.score.max"];
      }
      if (!data.hasOwnProperty("cmi.core.score.scaled")) {
        if (
          data.hasOwnProperty("cmi.core.score.raw") &&
          data.hasOwnProperty("cmi.core.score.max") &&
          Number(data["cmi.core.score.max"]) > 0
        )
          data["cmi.core.score.scaled"] =
            data["cmi.core.score.raw"] / data["cmi.core.score.max"];
      }
      var api = this;

      jQuery.ajax({
        url: url,
        method: "PUT",
        contentType: "application/json",
        dataType: "json",
        data: JSON.stringify(data),
        beforeSend: function (xhr) {
          xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
        },
        success: function (response) {
          api._committing = false;
          api._cluevo_progress = response;
        },
        error: function (xhr) {
          api._committing = false;
          if (xhr.responseJSON) {
            if (xhr.responseJSON.message !== api._lastCommitError) {
              cluevoAlert(
                cluevoStrings.message_title_error,
                xhr.responseJSON.message,
                "error"
              );
              api._lastCommitError = xhr.responseJSON.message;
            }
          } else {
            if (cluevoStrings.message_commit_error !== api._lastCommitError) {
              cluevoAlert(
                cluevoStrings.message_title_error,
                cluevoStrings.message_commit_error,
                "error"
              );
              api._lastCommitError = cluevoStrings.message_commit_error;
            }
          }
        },
      });
      this._committing = false;
      return "true";
    } else {
      console.warn("failed to commit");
      this._committing = false;
      cluevoAlert(
        cluevoStrings.message_title_error,
        cluevoStrings.message_commit_no_item_id_error,
        "error"
      );
      return "false";
    }
  },
  CommitData: function (input) {
    return this.Commit();
  },
  getHandle: function () {
    return this;
  },
  GetStudentName: function () {
    console.log("get student name");
  },
  GetDiagnostic: function () {
    var string = "Diagnostic: " + this.LastError;
    this.LastError = 0;
    return string;
  },
  Terminate: function () {
    if (this._terminated || this._terminating) return;
    console.log("terminating api");
    this._terminating = true;
    this.Values = {};
    this.ModuleRunning = false;
    this.Initialized = false;
    this.LastError = 0;
    let tmpId = parseInt(this.ItemId, 10);
    this.ItemId = null;
    scorm.connection.isActive = false;
    if (cluevo_scorm_window !== null) {
      cluevo_scorm_window.close();
      cluevo_scorm_window = null;
    }
    if (cluevoCommitTimer) {
      console.log("terminating", cluevoCommitTimer);
      clearInterval(cluevoCommitTimer);
    }

    let cancelClose = false;
    if (
      this._cluevo_progress &&
      this._cluevo_progress.hasOwnProperty("completion_status") &&
      this._cluevo_progress.hasOwnProperty("success_status") &&
      this._cluevo_progress.hasOwnProperty("lesson_status")
    ) {
      if (
        (this._cluevo_progress.completion_status == "completed" &&
          this._cluevo_progress.success_status == "passed") ||
        this._cluevo_progress.lesson_status == "passed"
      ) {
        cancelClose = window.dispatchEvent(
          new CustomEvent("cluevo_module_passed", { detail: tmpId })
        );
        if (!cancelClose) {
          location.reload(true);
        }
      }
    }

    if (!cancelClose) {
      cluevoCloseLightbox();
    }
    this._cluevo_progress = {};
    this._terminated = true;
    this._terminating = false;
    return "true";
  },
  LMSInitialize: function () {
    return this.Initialize();
  },
  LMSFinish: function () {
    return this.Terminate();
  },
  LMSGetValue: function (key) {
    return this.GetValue(key);
  },
  LMSSetValue: function (key, value) {
    return this.SetValue(key, value);
  },
  LMSCommit: function () {
    return this.Commit();
  },
  LMSGetLastError: function () {
    return this.GetLastError();
  },
  LMSGetErrorString: function () {
    return this.GetLastErrorString();
  },
  LMSGetDiagnostic: function () {
    return this.GetDiagnostic();
  },
  _cluevo_progress: {},
  _terminated: false,
  _terminating: false,
  _committing: false,
  _lastCommit: null,
  _lastCommitError: null,
};

//var API = API_1484_11;
var API_1484_11 = null;
var API = null;

function initCluevoLmsApi(itemId, module, skipPrompt) {
  skipPrompt = skipPrompt || false;
  if (cluevo_scorm_window === null) {
    var url =
      cluevoWpApiSettings.root + "cluevo/v1/modules/" + itemId + "/parameters";
    module = module || false;
    jQuery.ajax({
      url: url,
      method: "GET",
      contentType: "application/json",
      dataType: "json",
      beforeSend: function (xhr) {
        xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
      },
      success: function (response) {
        if (response.hasOwnProperty("_scorm_version")) {
          scorm.version = response._scorm_version;
          if (scorm.version === "1.2") {
            API_1484_11 = null;
            API = scorm_api;
          } else {
            API = null;
            API_1484_11 = scorm_api;
          }
        }
        if (
          !skipPrompt &&
          response.hasOwnProperty("cmi.suspend_data") &&
          !response["_resume"]
        ) {
          if (
            response["cmi.suspend_data"].value &&
            response["cmi.suspend_data"].value != ""
          ) {
            var startOver = showResumePrompt(
              itemId,
              response,
              function (value, parms) {
                if (value == true && parms) {
                  response = parms;
                }
                scorm_api.prime(itemId);
                var lmsConnected = scorm.init();
                var curApi = scorm.API.get();
                curApi.Values = {};
                for (var key in response) {
                  if (response[key]) curApi.Values[key] = response[key].value;
                }
                curApi.ItemId = itemId;
                if (!lmsConnected) {
                  // TODO: Handle lms connection failed
                  console.error("LMS CONNECTION FAILED");
                  cluevoAlert(
                    cluevoStrings.message_title_error,
                    cluevoStrings.lms_connection_error,
                    "error"
                  );
                } else {
                  if (module !== false) {
                    cluevo_scorm_window = window.open(module);
                  }
                }
              }
            );
          }
        } else {
          scorm_api.prime(itemId);
          var lmsConnected = scorm.init();
          var curApi = scorm.API.get();
          curApi.Values = {};
          for (var key in response) {
            if (response[key]) curApi.Values[key] = response[key].value;
          }
          curApi.ItemId = itemId;
          if (!lmsConnected) {
            // TODO: Handle lms connection failed
            console.error("LMS CONNECTION FAILED");
            cluevoAlert(
              cluevoStrings.message_title_error,
              cluevoStrings.lms_connection_error,
              "error"
            );
          } else {
            if (module !== false) {
              cluevo_scorm_window = window.open(module);
            }
          }
        }
      },
      error: function (xhr) {
        if (xhr.responseJSON) {
          cluevoAlert(
            cluevoStrings.message_title_error,
            xhr.responseJSON.message,
            "error"
          );
        } else {
          cluevoAlert(
            cluevoStrings.message_title_error,
            cluevoStrings.message_unknown_error,
            "error"
          );
        }
      },
    });
  } else {
    cluevoAlert(
      cluevoStrings.message_title_error,
      cluevoStrings.message_module_already_running,
      "error"
    );
  }
}

async function initIframe(itemId, module, next) {
  var url =
    cluevoWpApiSettings.root + "cluevo/v1/modules/" + itemId + "/parameters";
  module = module || false;
  var success = false;
  await jQuery.ajax({
    url: url,
    method: "GET",
    contentType: "application/json",
    dataType: "json",
    beforeSend: function (xhr) {
      xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
    },
    success: function (response) {
      if (response.hasOwnProperty("_scorm_version")) {
        scorm.version = response._scorm_version;
        if (scorm.version === "1.2") {
          API_1484_11 = null;
          API = scorm_api;
        } else {
          API = null;
          API_1484_11 = scorm_api;
        }
      }
      if (response.hasOwnProperty("cmi.suspend_data") && !response["_resume"]) {
        if (
          response["cmi.suspend_data"].value &&
          response["cmi.suspend_data"].value != ""
        ) {
          var startOver = showResumePrompt(
            itemId,
            response,
            function (value, parms) {
              // cluevoCloseLightbox();
              if (value == true && parms) {
                response = parms;
              }
              iframeInitSuccess(
                itemId,
                module,
                response,
                function (success, module) {
                  if (typeof next === "function") {
                    if (success) {
                      next(true, module);
                    } else {
                      next(false);
                    }
                  }
                }
              );
            }
          );
        }
      } else {
        iframeInitSuccess(itemId, module, response, function (success, module) {
          if (typeof next === "function") {
            if (success) {
              next(true, module);
            } else {
              next(false);
            }
          }
        });
      }
    },
  });
  return success;
}

function iframeInitSuccess(itemId, module, response, next) {
  jQuery("iframe#cluevo-module-iframe").attr(
    "src",
    jQuery("iframe#cluevo-module-iframe").data("src")
  );
  scorm_api.prime(itemId);
  var lmsConnected = scorm.init();
  var curApi = scorm.API.get();
  curApi.Values = {};
  for (var key in response) {
    if (response[key]) curApi.Values[key] = response[key].value;
  }
  curApi.ItemId = itemId;
  if (!lmsConnected) {
    // TODO: Handle lms connection failed
  } else {
    if (module !== false) {
      if (jQuery("#cluevo-module-iframe").length === 1) {
        jQuery("#cluevo-module-iframe").attr("src", module);
        jQuery([document.documentElement, document.body]).animate(
          {
            scrollTop: jQuery("#cluevo-module-iframe").offset().top - 50,
          },
          500
        );
      } else {
        success = true;
        next(true, module);
      }
    } else {
      next(false);
      success = false;
      return false;
    }
  }
}

function initApiWithItem(itemId, callback) {
  var url = cluevoWpApiSettings.root + "cluevo/v1/items/" + itemId;
  jQuery.ajax({
    url: url,
    method: "GET",
    contentType: "application/json",
    beforeSend: function (xhr) {
      xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
    },
    success: function (response) {
      callback(response);
    },
    error: function (xhr) {
      if (xhr.responseJSON) {
        cluevoAlert(
          cluevoStrings.message_title_error,
          xhr.responseJSON.message,
          "error"
        );
      } else {
        cluevoAlert(
          cluevoStrings.message_title_error,
          cluevoStrings.message_unknown_error,
          "error"
        );
      }
    },
  });
}

jQuery(document).ready(function () {
  if (jQuery("iframe#cluevo-module-iframe").length >= 1) {
    var itemId = jQuery("iframe#cluevo-module-iframe").data("item-id");
    initCluevoLmsApi(itemId, false, true);
  }

  jQuery(".cluevo-module-link").click(function (e) {
    cluevoRemoveTileOverlays();
  });

  if (jQuery("video.cluevo-media-module").length > 0) {
    window.onbeforeunload = function (e) {
      var moduleId = jQuery("video.cluevo-media-module").data("module-id");
      var video = jQuery("video.cluevo-media-module:first")[0];
      if (video && video.played.length > 0) {
        var max = video.duration;
        var score = video.ended ? video.duration : video.currentTime;
        var data = {
          id: moduleId,
          max: max,
          score: score,
        };

        var url =
          cluevoWpApiSettings.root +
          "cluevo/v1/modules/" +
          moduleId +
          "/progress";
        jQuery.ajax({
          url: url,
          method: "POST",
          contentType: "application/json",
          dataType: "json",
          data: JSON.stringify(data),
          beforeSend: function (xhr) {
            xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
          },
          success: function (response) {
            // TODO: Handle success
          },
        });
      }
    };
  }

  jQuery(".cluevo-module-link.cluevo-module-mode-popup").click(function (e) {
    var item = this;
    e.preventDefault();
    if (cluevo_scorm_window !== null) {
      cluevo_scorm_window.close();
      cluevo_scorm_window = null;
      scorm.connection.isActive = false;
    }
    var data = jQuery(this).data();
    var itemId = data.itemId;
    var type = data.moduleType;
    if (type === "scorm 2004") {
      var url = cluevoWpApiSettings.root + "cluevo/v1/items/" + itemId;
      jQuery.ajax({
        url: url,
        method: "GET",
        contentType: "application/json",
        beforeSend: function (xhr) {
          xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
        },
        success: function (response) {
          if (response.access) {
            if (response.scos && response.scos.length > 0) {
              if (response.scos.length == 1) {
                initCluevoLmsApi(itemId, response.scos[0].href);
              } else {
                showScoSelect(itemId, response.scos, async function (e) {
                  var href = jQuery(this).attr("href");
                  initCluevoLmsApi(itemId, href);
                  return;
                });
                return;
              }
            } else {
              if (response.iframe_index) {
                initCluevoLmsApi(itemId, response.iframe_index);
              } else {
                cluevoAlert(
                  cluevoStrings.message_title_error,
                  cluevoStrings.error_loading_module,
                  "error"
                );
              }
            }
          } else {
            let text =
              data.access_denied_text && data.access_denied_text != ""
                ? data.access_denied_text
                : cluevoStrings.message_access_denied;
            cluevoAlert(
              cluevoStrings.message_title_access_denied,
              text,
              "error"
            );
          }
        },
      });
    } else {
      switch (type) {
        case "audio":
        case "video":
          var url = cluevoWpApiSettings.root + "cluevo/v1/items/" + itemId;
          jQuery.ajax({
            url: url,
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            beforeSend: function (xhr) {
              xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
            },
            success: function (response) {
              switch (type) {
                case "audio":
                case "video":
                  var mediaWindow = window.open(response.iframe_index);
                  mediaWindow.onbeforeunload = function (e) {
                    var video = jQuery(mediaWindow.document)
                      .find("video")
                      .first()[0];
                    var moduleId = response.module_id;
                    if (video) {
                      var max = video.duration;
                      var score = video.ended
                        ? video.duration
                        : video.currentTime;
                      var data = {
                        id: moduleId,
                        max: max,
                        score: score,
                      };

                      var url =
                        cluevoWpApiSettings.root +
                        "cluevo/v1/modules/" +
                        moduleId +
                        "/progress";
                      jQuery.ajax({
                        url: url,
                        method: "POST",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify(data),
                        beforeSend: function (xhr) {
                          xhr.setRequestHeader(
                            "X-WP-Nonce",
                            cluevoWpApiSettings.nonce
                          );
                        },
                        success: function (response) {
                          // TODO: Handle success
                        },
                      });
                    }
                  };
                  break;
                default:
              }
            },
          });
          break;
        default:
      }
    }
  });

  jQuery(".cluevo-module-link.cluevo-module-mode-lightbox").click(function (e) {
    e.preventDefault();
    var data = jQuery(this).data();
    var itemId = data.itemId;
    var moduleId = data.moduleId;
    var type = data.moduleType;
    if (type === "scorm 2004") {
      initApiWithItem(itemId, async function (response) {
        scorm.connection.isActive = false;
        if (response.access) {
          if (response.scos && response.scos.length > 0) {
            if (response.scos.length == 1) {
              var success = await initIframe(
                itemId,
                response.scos[0].href,
                function (success, module) {
                  if (success) {
                    cluevoOpenLightbox(data);
                    cluevoShowLightbox();
                    cluevoShowLightboxSpinner();
                    var iframe = jQuery(
                      '<iframe src="' + module + '"></iframe>'
                    );
                    iframe.on("load", handleIframeLoaded);
                    iframe.appendTo("#cluevo-module-lightbox-overlay");
                    cluevoHideLightboxSpinner();
                  }
                }
              );
            } else {
              showScoSelect(itemId, response.scos, async function (e) {
                e.preventDefault();
                cluevoOpenLightbox(data);
                cluevoShowLightbox();
                cluevoShowLightboxSpinner();
                var success = await initIframe(
                  itemId,
                  e.target.href,
                  function (success, module) {
                    if (success) {
                      var iframe = jQuery(
                        '<iframe src="' + module + '"></iframe>'
                      );
                      iframe.on("load", handleIframeLoaded);
                      iframe.appendTo("#cluevo-module-lightbox-overlay");
                      cluevoHideLightboxSpinner();
                    }
                  }
                );
              });
              return;
            }
          } else {
            var success = await initIframe(
              itemId,
              response.iframe_index,
              function (success) {
                cluevoOpenLightbox(data);
                cluevoShowLightbox();
                if (!success) {
                  jQuery("#cluevo-module-lightbox-overlay")
                    .find(".cluevo-spinner-container")
                    .fadeOut(500, function () {
                      jQuery(this).remove();
                      jQuery(
                        '<div class="cluevo-error"><div class="cluevo-error-msg">' +
                          cluevoStrings.error_loading_module +
                          '</div><div class="cluevo-btn cluevo-error-close-button auto">' +
                          cluevoStrings.error_message_close +
                          "</div></div>"
                      ).appendTo(jQuery("#cluevo-module-lightbox-overlay"));
                    });
                } else {
                  var iframe = jQuery(
                    '<iframe src="' + response.iframe_index + '"></iframe>'
                  );
                  iframe.on("load", handleIframeLoaded);
                  iframe.appendTo("#cluevo-module-lightbox-overlay");
                  cluevoHideLightboxSpinner();
                }
              }
            );
          }
        } else {
          let text =
            data.access_denied_text && data.access_denied_text != ""
              ? data.access_denied_text
              : cluevoStrings.message_access_denied;
          cluevoAlert(cluevoStrings.message_title_access_denied, text, "error");
        }
      });
    } else {
      if (type == "audio" || type == "video") {
        var url = cluevoWpApiSettings.root + "cluevo/v1/items/" + itemId;
        jQuery.ajax({
          url: url,
          method: "GET",
          contentType: "application/json",
          dataType: "json",
          beforeSend: function (xhr) {
            xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
          },
          success: function (response) {
            switch (type) {
              case "audio":
              case "video":
                jQuery(
                  '<div id="cluevo-module-lightbox-overlay" data-module-id="' +
                    response.module_id +
                    '"' +
                    'data-item-id="' +
                    itemId +
                    '" class="cluevo-media"><video src="' +
                    response.iframe_index +
                    '" autoplay controls></video><div class="cluevo-close-button cluevo-btn cluevo-media">&times;</div></div>'
                )
                  .css({ display: "flex" })
                  .appendTo("body");
                jQuery("body, html").addClass("cluevo-module-overlay-active");
                jQuery("#cluevo-module-lightbox-overlay").fadeIn();
                break;
              default:
            }
          },
        });
      }
    }
  });

  jQuery(document).on(
    "click",
    "#cluevo-module-lightbox-overlay div.cluevo-close-button, #cluevo-module-lightbox-overlay div.cluevo-error-close-button",
    function () {
      if (jQuery(this).hasClass("cluevo-media")) {
        var video = jQuery("#cluevo-module-lightbox-overlay")
          .find("video")
          .first()[0];
        var moduleId = jQuery("#cluevo-module-lightbox-overlay").data(
          "module-id"
        );
        if (video) {
          var max = video.duration;
          var score = video.ended ? video.duration : video.currentTime;
          var data = {
            id: moduleId,
            max: max,
            score: score,
          };

          var url =
            cluevoWpApiSettings.root +
            "cluevo/v1/modules/" +
            moduleId +
            "/progress";
          jQuery.ajax({
            url: url,
            method: "POST",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify(data),
            beforeSend: function (xhr) {
              xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
            },
            success: function (response) {
              // TODO: Handle succcess
            },
          });
        }
      }
      cluevoCloseLightbox();
    }
  );

  if (jQuery("#cluevo-module-iframe").length > 0) {
    var data = jQuery("#cluevo-module-iframe").data();
    var itemId = data.itemId;
    initApiWithItem(itemId, async function (response) {
      scorm.connection.isActive = false;
      if (response.access) {
        if (response.scos && response.scos.length > 0) {
          if (response.scos.length == 1) {
            jQuery(
              "#cluevo-module-lightbox-overlay .cluevo-spinner-container"
            ).show();
            var success = await initIframe(
              itemId,
              response.scos[0].href,
              function (success) {
                if (success) {
                  jQuery(
                    "#cluevo-module-lightbox-overlay .cluevo-sco-select-container"
                  ).hide();
                }
              }
            );
          } else {
            showScoSelect(itemId, response.scos, async function (e) {
              e.preventDefault();
              jQuery(
                "#cluevo-module-lightbox-overlay .cluevo-spinner-container"
              ).show();
              var success = await initIframe(itemId, jQuery(this).attr("href"));
              if (success) {
                jQuery(
                  "#cluevo-module-lightbox-overlay .cluevo-sco-select-container"
                ).hide();
              }
            });
          }
          return;
        } else {
          initIframe(itemId, response.iframe_index);
        }
      } else {
        let text =
          data.access_denied_text && data.access_denied_text != ""
            ? data.access_denied_text
            : cluevoStrings.message_access_denied;
        cluevoAlert(cluevoStrings.message_title_access_denied, text, "error");
      }
    });
  }
});

function cluevoRemoveTileOverlays() {
  jQuery(".cluevo-sco-select-container").remove();
  jQuery(".cluevo-module-tile-overlay").remove();
}

async function showScoSelect(itemId, list, startFunc) {
  cluevoRemoveTileOverlays();
  let el =
    '<div class="cluevo-sco-select-container"><h2>' +
    cluevoStrings.sco_select_title +
    "</h2><ul>";
  var items = list.map(function (el) {
    return '<li><a href="' + el.href + '">' + el.title + "</a></li>";
  });
  el += items.join("\n");
  el += "</ul></div>";
  var sel = jQuery(el);
  sel.on("click", "a", startFunc);
  sel.on("click", "a", function (e) {
    e.stopPropagation();
    e.preventDefault();
    jQuery(sel).remove();
  });
  jQuery(
    '.cluevo-content-item-link[data-item-id="' +
      itemId +
      '"] .cluevo-post-thumb:first'
  ).append(sel);
  jQuery(sel).fadeIn();
}

async function showResumePrompt(itemId, data, callback) {
  cluevoRemoveTileOverlays();
  var el =
    '<div class="cluevo-module-tile-overlay"><h2>' +
    cluevoStrings.start_over_dialog_header +
    '</h2><div class="cluevo-prompt-btns-container"><div class="cluevo-btn yes">' +
    cluevoStrings.start_over_opt_reset +
    '</div><div class="cluevo-btn no">' +
    cluevoStrings.start_over_opt_resume +
    "</div></div></div>";
  var dialog = jQuery(el);
  var needLightbox =
    jQuery(
      '.cluevo-content-item-link[data-item-id="' +
        itemId +
        '"] .cluevo-post-thumb:first'
    ).length === 0;
  dialog.on("click", ".cluevo-btn.yes", async function () {
    var url =
      cluevoWpApiSettings.root + "cluevo/v1/modules/" + itemId + "/new-attempt";
    await jQuery.ajax({
      url: url,
      method: "GET",
      contentType: "application/json",
      dataType: "json",
      beforeSend: function (xhr) {
        xhr.setRequestHeader("X-WP-Nonce", cluevoWpApiSettings.nonce);
      },
      success: function (response) {
        jQuery(dialog).remove();
        if (needLightbox) {
          cluevoCloseLightbox();
        }
        callback(true, response);
      },
    });
  });
  dialog.on("click", ".cluevo-btn.no", function () {
    jQuery(dialog).remove();
    if (needLightbox) {
      cluevoCloseLightbox();
    }
    callback(false);
  });
  dialog.on("click", ".cluevo-btn", function (e) {
    e.stopPropagation();
    e.preventDefault();
    jQuery(dialog).remove();
    if (needLightbox) {
      cluevoCloseLightbox();
    }
  });
  if (!needLightbox) {
    jQuery(
      '.cluevo-content-item-link[data-item-id="' +
        itemId +
        '"] .cluevo-post-thumb:first'
    ).append(dialog);
  } else {
    cluevoOpenLightbox(null, "", dialog);
    cluevoShowLightbox();
  }
  jQuery(dialog).fadeIn();
}

async function cluevoShowModuleRating(itemId, moduleId, progress, startFunc) {
  if (!jQuery("body").hasClass("logged-in")) return;
  cluevoRemoveTileOverlays();
  let el =
    '<div class="cluevo-rating-overlay-container cluevo-module-tile-overlay"><h2 class="cluevo-rating-headline">' +
    cluevoStrings.rate +
    '</h2><div id="cluevo-rating-target"></div>';
  el += "</div>";
  var sel = jQuery(el);
  sel.on("change", "select", startFunc);
  sel.on(
    "click",
    ".cluevo-module-rating-container, .cluevo-module-rating",
    function (e) {
      e.stopPropagation();
      e.preventDefault();
    }
  );
  let itemLink = jQuery(
    '.cluevo-content-item-link[data-item-id="' +
      itemId +
      '"] .cluevo-post-thumb:first'
  );
  if (itemLink && itemLink.length > 0) {
    jQuery(
      '.cluevo-content-item-link[data-item-id="' +
        itemId +
        '"] .cluevo-post-thumb:first'
    ).append(sel);
  } else {
    jQuery(
      '.cluevo-toc-item[data-item-id="' + itemId + '"] .cluevo-toc-item-content'
    ).append(sel);
  }
  let rating = new cluevoModuleRating({
    propsData: {
      rating: 3,
      itemId: itemId,
      moduleId: moduleId,
      progress: progress,
    },
  });
  rating.$mount();
  jQuery("#cluevo-rating-target").append(rating.$el);
  jQuery(sel).fadeIn(100, function () {
    jQuery(sel).css("display", "flex");
    setTimeout(function () {
      jQuery([document.documentElement, document.body]).animate(
        {
          scrollTop:
            jQuery("#cluevo-rating-target").parents("a:first").offset().top -
            20,
        },
        300
      );
    }, 500);
  });
}

jQuery(window).on("cluevo_closing_lightbox", function (e) {
  if (cluevoSettings.ratingsEnabled == 0) return;
  let progress = JSON.parse(JSON.stringify(scorm_api._cluevo_progress));
  progress = progress || null;
  if (!e || !e.detail || !e.detail.moduleId) return;
  cluevoShowModuleRating(
    e.detail.itemId,
    e.detail.moduleId,
    progress,
    function (event) {
      cluevoRemoveTileOverlays();
    }
  );
});

function handleIframeLoaded() {
  jQuery("#cluevo-module-lightbox-overlay")
    .find(".cluevo-spinner-container")
    .fadeOut(500, function () {
      jQuery(this).remove();
    });
}
jQuery(".iframe-sco-select").change(function (e) {
  var itemId = jQuery("iframe#cluevo-module-iframe").data("item-id");
  if (jQuery(this).val() != 0) {
    jQuery("iframe#cluevo-module-iframe").attr("src", jQuery(this).val());
    initCluevoLmsApi(itemId);
  }
});

const cluevoModuleRatingComp = Vue.component("cluevo-module-rating", {
  props: ["rating", "itemId", "moduleId", "progress"],
  data: function () {
    return {
      value: 1,
      hovering: 1,
      working: false,
    };
  },
  methods: {
    rate: function (e, n) {
      e.stopPropagation();
      e.preventDefault();
      this.value = parseInt(n, 10);
      this.working = true;
      jQuery
        .post(cluevoModuleRatings.ajax_url, {
          action: cluevoModuleRatings.action,
          rating: n,
          moduleId: this.moduleId,
          itemId: this.itemId,
          progress: this.progress,
          nonce: cluevoModuleRatings.nonce,
        })
        .done(function () {
          this.working = false;
          location.reload();
          cluevoRemoveTileOverlays();
        })
        .error(function () {
          this.working = false;
          cluevoRemoveTileOverlays();
        });
    },
  },
  template: `
  <div id="cluevo-module-rating" class="cluevo-module-rating-container">
    <div v-if="!working" class="cluevo-module-stars">
      <div
        v-for="n in 5"
        class="cluevo-module-rating"
        :class="[{ filled: hovering >= n }]"
        @mouseover="hovering = n"
        @click="rate($event, n)"
      ></div>
    </div>
    <div v-else>{{ window.cluevoStrings.working }}</div>
  </div>
  `,
});

const cluevoModuleRating = Vue.extend(cluevoModuleRatingComp);
