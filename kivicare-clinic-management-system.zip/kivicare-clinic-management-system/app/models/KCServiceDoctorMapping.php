<?php

namespace App\models;

use App\baseClasses\KCModel;

class KCServiceDoctorMapping extends KCModel {

    public function __construct()
    {
        parent::__construct('service_doctor_mapping');
    }

}