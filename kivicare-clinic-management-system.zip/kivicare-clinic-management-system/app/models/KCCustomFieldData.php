<?php


namespace App\models;

use App\baseClasses\KCModel;

class KCCustomFieldData extends KCModel {

	public function __construct()
	{
		parent::__construct('custom_fields_data');
	}


}