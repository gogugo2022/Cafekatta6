<?php
/**
 * Base field class.
 *
 * @package Google\Web_Stories
 */

/**
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

namespace Google\Web_Stories\Renderer\Stories\Fields;

use Google\Web_Stories\Interfaces\Field;

/**
 * Class BaseField.
 *
 * @package Google\Web_Stories\Renderer\Stories\Fields
 */
class BaseField implements Field {
	/**
	 * Field label.
	 *
	 * @var string
	 */
	private $label;

	/**
	 * Whether the field is enabled.
	 *
	 * @var bool
	 */
	private $hidden;

	/**
	 * Whether to display the field.
	 *
	 * @var bool
	 */
	private $show;

	/**
	 * BaseField constructor.
	 *
	 * @param array $args Arguments.
	 */
	public function __construct( array $args ) {
		$this->label  = $args['label'] ?? '';
		$this->hidden = isset( $args['hidden'] ) ? (bool) $args['hidden'] : true;
		$this->show   = isset( $args['show'] ) ? (bool) $args['show'] : true;
	}

	/**
	 * Label for the field.
	 *
	 * @return string
	 */
	public function label(): string {
		return (string) $this->label;
	}

	/**
	 * Flag for field display.
	 *
	 * @return bool
	 */
	public function show(): bool {
		return (bool) $this->show;
	}

	/**
	 * Whether the field is hidden.
	 *
	 * @return bool
	 */
	public function hidden(): bool {
		return (bool) $this->hidden;
	}
}
