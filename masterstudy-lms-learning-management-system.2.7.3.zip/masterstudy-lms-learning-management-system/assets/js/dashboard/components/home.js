"use strict";

var stm_lms_components = {};
stm_lms_components['home'] = {
  template: '#stm-lms-dashboard-home'
};