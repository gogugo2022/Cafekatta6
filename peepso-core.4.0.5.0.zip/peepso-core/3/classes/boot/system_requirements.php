<?php

class PeepSo3_System_Requirements {

    const PHP_REQUIRED = '7.3.0';
    const PHP_RECOMMENDED = '7.4.0';

}