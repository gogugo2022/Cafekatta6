import about from './about';

function init() {
	about.init();
}

export default { init };
