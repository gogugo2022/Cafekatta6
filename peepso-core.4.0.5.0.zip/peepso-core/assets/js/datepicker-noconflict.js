(function ($) {
	if ($.fn.datepicker) {
		window.peepso_datepicker_noconflict = $.fn.datepicker;
	}
})(jQuery);
